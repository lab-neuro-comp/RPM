# Matrizes Progressivas de Raven

Este manual foi escrito pensado no aplicador do teste.

```
TODO Write about test, how to create a test and how the application works.
```
